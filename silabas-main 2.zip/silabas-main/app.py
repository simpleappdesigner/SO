from flask import Flask, render_template, request
from io import BytesIO
#from syllable import syllable
import os

app = Flask(__name__)
app.config['UPLOAD_PATH'] = "."

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['file']
    file_path = os.path.join(app.config['UPLOAD_PATH'], file.filename)
    file.save(file_path)
    #syllable(file_path, "red", "es")
    return "File processed successfully."

if __name__ == '__main__':
    app.run()
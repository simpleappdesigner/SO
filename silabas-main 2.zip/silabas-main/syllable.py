import io
import os
import pyphen
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
import reportlab
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.pdfpage import PDFPage
import re

def syllable(pdf, font_color, language):
    # Register the Helvetica and Times fonts with ReportLab
    reportlab.rl_config.warnOnMissingFontGlyphs = 0
    pdfmetrics.registerFont(TTFont('Arial', 'arial.ttf'))

    # Define the path to the input and output PDF files
    input_file = pdf
    output_file = 'output.pdf'

    # Load the Pyphen library and create a dictionary for the hyphenation rules
    dic = pyphen.Pyphen(lang=language)

    # Load the input PDF file and extract its text using the extract_text_from_pdf function
    def extract_text_from_pdf(pdf_path):
        with open(pdf_path, 'rb') as fp, io.StringIO() as output_string:
            resource_manager = PDFResourceManager()
            laparams = LAParams()
            converter = TextConverter(resource_manager, output_string, laparams=laparams)
            interpreter = PDFPageInterpreter(resource_manager, converter)
            password = ""
            maxpages = 0
            caching = True
            pagenos = None

            rsrcmgr = PDFResourceManager()
            device = TextConverter(rsrcmgr, output_string, laparams=LAParams())

            # Create a PDF interpreter and process each page of the PDF file
            for page in PDFPage.get_pages(fp, pagenos, maxpages=maxpages, password=password,
                                        caching=caching, check_extractable=True):
                interpreter = PDFPageInterpreter(rsrcmgr, device)
                interpreter.process_page(page)

            # Get the text from the output string and close the converter
            text = output_string.getvalue()
            device.close()
            output_string.close()
            return text

    text = extract_text_from_pdf(input_file)

    # Split the text into words and newline characters
    words = re.findall(r'\S+|\n', text)

    # Separate the text into syllables using the Pyphen library
    syllables = []
    for word in words:
        if word == b'\n':
            # Add the newline character to the list
            syllables.append((word, ""))
        else:
            syl_list = dic.inserted(word).split("-")
            for i, syl in enumerate(syl_list):
                if syl:
                    # Add the syllable to the list
                    syllables.append((syl, ""))

                    # Add a space as a separate syllable, except for the last syllable in the word
                    if i == len(syl_list) - 1:
                        syllables.append((" ", ""))
    syllables = [syl[0].encode('utf-8') for syl in syllables]

    # Create a new PDF file with the colored syllables
    output_buffer = io.BytesIO()
    c = canvas.Canvas(output_buffer, pagesize=letter)
    c.setFontSize(12)
    styles = getSampleStyleSheet()

    x = 0.5 * inch
    y = 10.5 * inch

    # Define initial color and flag
    previous_color = "black"
    previous_non_space_color = "black"

    # Define initial color and flag
    previous_color = font_color
    previous_non_space_color = "black"

    for syl in syllables:
        if syl == b' ':
            color = previous_non_space_color
        else:
            if previous_color == "black":
                color = font_color
            else:
                color = "black"
            previous_color = color
            previous_non_space_color = color
        if syl == b'\n':  # Check if the syllable is a newline
            color = "white"
        c.setFillColor(color)

        # Add the syllable to the canvas
        textobject = c.beginText()
        textobject.setTextOrigin(x, y)
        textobject.setFont('Arial', 12)
        textobject.textLine(syl.decode('utf-8'))
        c.drawText(textobject)

        # Move to the next position on the canvas
        if syl == b'\n':  # Check if the syllable is a newline
            x = 0.5 * inch  # Reset the x-coordinate
            y -= 0.2 * inch  # Decrease the y-coordinate
        else:
            textobject.textLine(syl.decode('utf-8'))  # Add the syllable to the canvas normally
            x += c.stringWidth(syl.decode('utf-8'), 'Arial', 12)
            if x > 7.5 * inch:
                x = 0.5 * inch
                y -= 0.2 * inch
            if y < 0.5 * inch:
                c.showPage()  # Move to a new page
                x = 0.5 * inch
                y = 10.5 * inch

    c.save()

    # Write the output PDF file to disk
    with open(output_file, 'wb') as fp:
        fp.write(output_buffer.getvalue())

    # Open the output PDF file in the default PDF viewer
    os.system(f'open "{output_file}"')